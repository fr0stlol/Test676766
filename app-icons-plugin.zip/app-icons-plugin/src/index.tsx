import { ToastActionCreators } from '@revenge-mod/discord/actions'
import { Design } from '@revenge-mod/discord/design'
import {
    addSettingsItemToSection,
    onSettingsModulesLoaded,
    refreshSettings,
    registerSettingsItem,
} from '@revenge-mod/discord/modules/settings'
import { callNativeMethod } from '@revenge-mod/modules/native'
import TableRowAssetIcon from '@revenge-mod/components/TableRowAssetIcon'
import { useCallback, useEffect, useState } from 'react'
import { ScrollView } from 'react-native'
import type { SettingsItem } from '@revenge-mod/discord/modules/settings'

interface IconState {
    aliases: { name: string; enabled: boolean }[]
    pinned: { id: string; label: string; enabled: boolean }[]
    pinSupported: boolean
}

declare module '@revenge-mod/modules/native' {
    interface NativeMethods {
        'appicons.state': [[], IconState]
        'appicons.set': [[name: string], null]
        'appicons.pin': [[id: string, label: string, pngBase64: string], boolean]
        'appicons.unpin': [[id: string], null]
    }
}

const SETTING_KEY = 'RevengeAppIcons'

function toast(text: string, critical = false) {
    ToastActionCreators.open('REVENGE_APP_ICONS', {
        text,
        ...(critical ? { variant: 'critical' } : {}),
    })
}

function errorText(e: unknown) {
    return e instanceof Error ? e.message : String(e)
}

/** Downloads an image and returns its base64 body, without the data: prefix. */
async function fetchBase64(url: string) {
    const res = await fetch(url)
    if (!res.ok) throw new Error(`HTTP ${res.status}`)
    const blob = await res.blob()

    return new Promise<string>((resolve, reject) => {
        const reader = new FileReader()
        reader.onloadend = () => resolve(String(reader.result).split(',')[1] ?? '')
        reader.onerror = () => reject(reader.error)
        reader.readAsDataURL(blob)
    })
}

function AppIconsScreen() {
    const [state, setState] = useState<IconState | null>(null)
    const [url, setUrl] = useState('')
    const [label, setLabel] = useState('')
    const [busy, setBusy] = useState(false)

    const refresh = useCallback(async () => {
        setState(await callNativeMethod('appicons.state', []))
    }, [])

    useEffect(() => {
        refresh().catch(e => toast(errorText(e), true))
    }, [refresh])

    const run = useCallback(
        async (fn: () => Promise<void>, done?: string) => {
            setBusy(true)
            try {
                await fn()
                if (done) toast(done)
            } catch (e) {
                toast(errorText(e), true)
            } finally {
                setBusy(false)
            }
        },
        [],
    )

    const addIcon = () =>
        run(async () => {
            const name = label.trim()
            if (!name) throw new Error('Enter a name for the icon')
            if (!url.trim()) throw new Error('Enter an image URL')

            const png = await fetchBase64(url.trim())
            const id = `${name.toLowerCase().replace(/[^a-z0-9]+/g, '_')}_${Date.now().toString(36)}`
            await callNativeMethod('appicons.pin', [id, name, png])

            setUrl('')
            setLabel('')
            // The system dialog is async. Refresh after the user has had time to confirm.
            setTimeout(() => refresh().catch(() => {}), 2000)
        }, 'Confirm the shortcut in the dialog that appears')

    return (
        <ScrollView>
            <Design.Stack spacing={16} style={{ padding: 16 }}>
                <Design.TableRowGroup title="Built-in icons">
                    {state?.aliases.length ? (
                        state.aliases.map(a => (
                            <Design.TableRow
                                key={a.name}
                                label={a.name}
                                trailing={
                                    a.enabled ? (
                                        <Design.Text variant="text-sm/medium">Active</Design.Text>
                                    ) : undefined
                                }
                                disabled={busy}
                                onPress={() =>
                                    run(async () => {
                                        await callNativeMethod('appicons.set', [a.name])
                                        await refresh()
                                    }, 'Icon changed. Your launcher may take a few seconds to update.')
                                }
                            />
                        ))
                    ) : (
                        <Design.TableRow
                            label="No built-in icons"
                            subLabel="Patch Discord with the icon aliases step in Revenge Manager"
                        />
                    )}
                </Design.TableRowGroup>

                <Design.TableRowGroup title="Custom icons (home screen shortcuts)">
                    {state?.pinned.map(p => (
                        <Design.TableRow
                            key={p.id}
                            label={p.label || p.id}
                            subLabel={
                                p.enabled
                                    ? 'Tap to disable. Remove the leftover from your home screen yourself.'
                                    : 'Disabled. Remove it from your home screen.'
                            }
                            variant="danger"
                            disabled={busy || !p.enabled}
                            onPress={() =>
                                run(async () => {
                                    await callNativeMethod('appicons.unpin', [p.id])
                                    await refresh()
                                }, 'Shortcut disabled')
                            }
                        />
                    ))}
                    {state && !state.pinned.length && (
                        <Design.TableRow label="No custom icons yet" />
                    )}
                </Design.TableRowGroup>

                {state && !state.pinSupported ? (
                    <Design.Text variant="text-sm/medium">
                        Your launcher does not support pinned shortcuts, so custom icons cannot be added.
                    </Design.Text>
                ) : (
                    <Design.Stack spacing={8}>
                        <Design.TextInput
                            label="Name"
                            placeholder="My icon"
                            value={label}
                            onChange={setLabel}
                        />
                        <Design.TextInput
                            label="Image URL"
                            placeholder="https://example.com/icon.png"
                            value={url}
                            onChange={setUrl}
                        />
                        <Design.Button
                            text="Add icon"
                            loading={busy}
                            disabled={busy}
                            onPress={addIcon}
                        />
                    </Design.Stack>
                )}
            </Design.Stack>
        </ScrollView>
    )
}

const AppIconsSetting: SettingsItem = {
    parent: null,
    type: 'route',
    IconComponent: () => <TableRowAssetIcon name="PaintPaletteIcon" />,
    useTitle: () => 'App Icons',
    screen: {
        route: SETTING_KEY,
        getComponent: () => AppIconsScreen,
    },
}

const cleanups: (() => void)[] = []

export default plugin({
    start() {
        cleanups.push(
            onSettingsModulesLoaded(() => {
                cleanups.push(
                    registerSettingsItem(SETTING_KEY, AppIconsSetting),
                    addSettingsItemToSection('REVENGE', SETTING_KEY),
                )
                refreshSettings()
            }),
        )
    },

    stop() {
        for (const cleanup of cleanups.splice(0)) cleanup()
        refreshSettings()
    },
})
