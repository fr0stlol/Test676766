# App Icons (Revenge Next plugin)

Adds Settings > App Icons with two lists:

- Built-in icons: the `app.revenge.icons.*` launcher aliases added by the revenge-manager
  AddIconAliasesStep patch. Tap one to switch.
- Custom icons: pinned home-screen shortcuts made from an image URL. Android cannot remove a pinned
  shortcut, so "remove" disables it and you delete the leftover from the home screen.

Files:

- `manifest.json`: native plugin manifest (format 1).
- `native/AppIconsPlugin.kt`: `appicons.state/set/pin/unpin` bridge methods (compile against `io.github.revenge:api`).
- `src/index.tsx`: JS plugin and settings page.

Build with revenge-plugin-template (not included here): it bundles `src/index.tsx` to `dist/index.js`
and the Kotlin file to `dist/native.jar`, then writes the manifest paths above.
