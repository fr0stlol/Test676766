package app.revenge.appicons

import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import io.github.revenge.bridge.RevengeBridge
import io.github.revenge.plugins.Plugin
import java.net.URL

class AppIconsPlugin : Plugin() {
    override fun onStart() {
        val context = RevengeBridge.context

        // 1. Get current active built-in icon state
        RevengeBridge.registerNativeMethod("appicons.state") { args ->
            val pkg = context.packageName
            val pm = context.packageManager
            val pInfo = pm.getPackageInfo(pkg, PackageManager.GET_ACTIVITIES or PackageManager.GET_DISABLED_COMPONENTS)
            
            pInfo.activities?.firstOrNull { it.name.startsWith("app.revenge.icons.") }?.let {
                listOf(it.name, it.enabledSetting == PackageManager.COMPONENT_ENABLED_STATE_ENABLED)
            } ?: listOf("none", false)
        }

        // 2. Switch built-in app icon alias
        RevengeBridge.registerNativeMethod("appicons.set") { args ->
            val aliasName = args.getOrNull(0) as? String ?: return@registerNativeMethod false
            val pkg = context.packageName
            val pm = context.packageManager

            val pInfo = pm.getPackageInfo(pkg, PackageManager.GET_ACTIVITIES or PackageManager.GET_DISABLED_COMPONENTS)
            pInfo.activities?.forEach { act ->
                if (act.name.startsWith("app.revenge.icons.")) {
                    pm.setComponentEnabledSetting(
                        ComponentName(pkg, act.name),
                        if (act.name == aliasName) PackageManager.COMPONENT_ENABLED_STATE_ENABLED
                        else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                        PackageManager.DONT_KILL_APP
                    )
                }
            }
            true
        }

        // 3. Pin custom shortcut with URL image icon
        RevengeBridge.registerNativeMethod("appicons.pin") { args ->
            val name = args.getOrNull(0) as? String ?: return@registerNativeMethod false
            val imageUrl = args.getOrNull(1) as? String ?: return@registerNativeMethod false

            try {
                val url = URL(imageUrl)
                val stream = url.openStream()
                val bitmap = BitmapFactory.decodeStream(stream)
                stream.close()

                if (bitmap != null && ShortcutManagerCompat.isRequestPinShortcutSupported(context)) {
                    val launchIntent = context.packageManager.getLaunchIntentForPackage(context.packageName)?.apply {
                        action = Intent.ACTION_VIEW
                    } ?: return@registerNativeMethod false

                    val shortcutInfo = ShortcutInfoCompat.Builder(context, "custom_shortcut_${System.currentTimeMillis()}")
                        .setShortLabel(name)
                        .setLongLabel(name)
                        .setIcon(IconCompat.createWithBitmap(bitmap))
                        .setIntent(launchIntent)
                        .build()

                    ShortcutManagerCompat.requestPinShortcut(shortcutInfo, null)
                    true
                } else {
                    false
                }
            } catch (e: Exception) {
                e.printStackTrace()
                false
            }
        }
    }
}
